
function orange()
{
var a,b,c; a=document.getElementById("htmlCode").style.color="orange";

b=document.getElementById("cssCode").style.color="orange";

c=document.getElementById("jquerycode").style.color="orange";

d=document.getElementById("jsCode").style.color="orange";
}

function red()
{
var a,b,c; a=document.getElementById("htmlCode").style.color="red";

b=document.getElementById("cssCode").style.color="red";

c=document.getElementById("jquerycode").style.color="red";

d=document.getElementById("jsCode").style.color="red";
}

function green()
{
var a,b,c; a=document.getElementById("htmlCode").style.color="green";

b=document.getElementById("cssCode").style.color="green";

c=document.getElementById("jquerycode").style.color="green";

d=document.getElementById("jsCode").style.color="green";
}

function deeppink()
{
var a,b,c; a=document.getElementById("htmlCode").style.color="deeppink";

b=document.getElementById("cssCode").style.color="deeppink";

c=document.getElementById("jquerycode").style.color="deeppink";

d=document.getElementById("jsCode").style.color="deeppink";
}

function blue()
{
var a,b,c; a=document.getElementById("htmlCode").style.color="blue";

b=document.getElementById("cssCode").style.color="blue";

c=document.getElementById("jquerycode").style.color="blue";

d=document.getElementById("jsCode").style.color="blue";
}

function lime()
{
var a,b,c; a=document.getElementById("htmlCode").style.color="lime";

b=document.getElementById("cssCode").style.color="lime";

c=document.getElementById("jquerycode").style.color="lime";

d=document.getElementById("jsCode").style.color="lime";
}

function aqua()
{
var a,b,c; a=document.getElementById("htmlCode").style.color="aqua";

b=document.getElementById("cssCode").style.color="aqua";

c=document.getElementById("jquerycode").style.color="aqua";

d=document.getElementById("jsCode").style.color="aqua";
}

function coral()
{
var a,b,c; a=document.getElementById("htmlCode").style.color="coral";

b=document.getElementById("cssCode").style.color="coral";

c=document.getElementById("jquerycode").style.color="coral";

d=document.getElementById("jsCode").style.color="coral";
}

function purple()
{
var a,b,c; a=document.getElementById("htmlCode").style.color="purple";

b=document.getElementById("cssCode").style.color="purple";

c=document.getElementById("jquerycode").style.color="purple";

d=document.getElementById("jsCode").style.color="purple";
}

function maroon()
{
var a,b,c; a=document.getElementById("htmlCode").style.color="maroon";

b=document.getElementById("cssCode").style.color="maroon";

c=document.getElementById("jquerycode").style.color="maroon";

d=document.getElementById("jsCode").style.color="maroon";
}

function teal()
{
var a,b,c; a=document.getElementById("htmlCode").style.color="teal";

b=document.getElementById("cssCode").style.color="teal";

c=document.getElementById("jquerycode").style.color="teal";

d=document.getElementById("jsCode").style.color="teal";
}

function crimson()
{
var a,b,c; a=document.getElementById("htmlCode").style.color="crimson";

b=document.getElementById("cssCode").style.color="crimson";

c=document.getElementById("jquerycode").style.color="crimson";

d=document.getElementById("jsCode").style.color="crimson";
}


